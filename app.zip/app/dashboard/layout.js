export const metadata = {
  title: "Dashboard - ShopSphere",
  description: "User dashboard for ShopSphere e-commerce platform",
};

export default function DashboardLayout({ children }) {
  return children;
}